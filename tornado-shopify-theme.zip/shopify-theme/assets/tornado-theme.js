/**
 * TORNADO LUXURY STREETWEAR — SHOPIFY THEME JAVASCRIPT (PHASE 3)
 */
document.addEventListener('DOMContentLoaded', () => {
  console.log('TORNADO Phase 3 JavaScript Initialized.');

  /* ------------------------------------------------------------------------
     1. STICKY & SCROLL HEADER
     ------------------------------------------------------------------------ */
  const header = document.querySelector('.tornado-header');
  if (header && header.dataset.headerSticky === 'true') {
    window.addEventListener('scroll', () => {
      if (window.scrollY > 40) {
        header.classList.add('is-scrolled');
      } else {
        header.classList.remove('is-scrolled');
      }
    }, { passive: true });
  }

  /* ------------------------------------------------------------------------
     2. MOBILE MENU DRAWER
     ------------------------------------------------------------------------ */
  const mobileToggle = document.querySelector('[data-mobile-menu-toggle]');
  const mobileDrawer = document.querySelector('[data-mobile-menu-drawer]');
  const mobileOverlay = document.querySelector('[data-mobile-menu-overlay]');
  const mobileClose = document.querySelector('[data-mobile-menu-close]');

  function openMobileMenu() {
    if (mobileDrawer && mobileOverlay) {
      mobileDrawer.classList.add('active');
      mobileOverlay.classList.add('active');
      mobileDrawer.setAttribute('aria-hidden', 'false');
      if (mobileToggle) mobileToggle.setAttribute('aria-expanded', 'true');
      document.body.style.overflow = 'hidden';
    }
  }

  function closeMobileMenu() {
    if (mobileDrawer && mobileOverlay) {
      mobileDrawer.classList.remove('active');
      mobileOverlay.classList.remove('active');
      mobileDrawer.setAttribute('aria-hidden', 'true');
      if (mobileToggle) mobileToggle.setAttribute('aria-expanded', 'false');
      document.body.style.overflow = '';
    }
  }

  if (mobileToggle) mobileToggle.addEventListener('click', openMobileMenu);
  if (mobileClose) mobileClose.addEventListener('click', closeMobileMenu);
  if (mobileOverlay) mobileOverlay.addEventListener('click', closeMobileMenu);

  /* ------------------------------------------------------------------------
     3. PREDICTIVE SEARCH OVERLAY
     ------------------------------------------------------------------------ */
  const searchToggles = document.querySelectorAll('[data-search-toggle]');
  const searchModal = document.querySelector('[data-search-modal]');
  const searchOverlay = document.querySelector('[data-search-overlay]');
  const searchClose = document.querySelector('[data-search-close]');
  const searchInput = document.querySelector('[data-predictive-search-input]');

  function openSearch() {
    if (searchModal && searchOverlay) {
      searchModal.classList.add('active');
      searchOverlay.classList.add('active');
      searchModal.setAttribute('aria-hidden', 'false');
      if (searchInput) setTimeout(() => searchInput.focus(), 100);
      document.body.style.overflow = 'hidden';
    }
  }

  function closeSearch() {
    if (searchModal && searchOverlay) {
      searchModal.classList.remove('active');
      searchOverlay.classList.remove('active');
      searchModal.setAttribute('aria-hidden', 'true');
      document.body.style.overflow = '';
    }
  }

  searchToggles.forEach(btn => btn.addEventListener('click', (e) => {
    e.preventDefault();
    openSearch();
  }));

  if (searchClose) searchClose.addEventListener('click', closeSearch);
  if (searchOverlay) searchOverlay.addEventListener('click', closeSearch);

  // Keyboard Escape Handler
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      closeMobileMenu();
      closeSearch();
      if (typeof closeCart === 'function') closeCart();
    }
  });

  /* ------------------------------------------------------------------------
     4. DROP COUNTDOWN TIMER
     ------------------------------------------------------------------------ */
  const countdownEl = document.querySelector('[data-drop-date]');
  if (countdownEl) {
    const dropDateStr = countdownEl.dataset.dropDate;
    const dropTarget = new Date(dropDateStr).getTime();

    function updateTimer() {
      const now = new Date().getTime();
      const diff = dropTarget - now;

      if (diff > 0) {
        const days = Math.floor(diff / (1000 * 60 * 60 * 24));
        const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));

        const daysEl = document.getElementById('timer-days');
        const hoursEl = document.getElementById('timer-hours');
        const minsEl = document.getElementById('timer-minutes');

        if (daysEl) daysEl.textContent = String(days).padStart(2, '0');
        if (hoursEl) hoursEl.textContent = String(hours).padStart(2, '0');
        if (minsEl) minsEl.textContent = String(minutes).padStart(2, '0');
      }
    }

    updateTimer();
    setInterval(updateTimer, 60000);
  }

  /* ------------------------------------------------------------------------
     5. WISHLIST LOCAL STORAGE HANDLER
     ------------------------------------------------------------------------ */
  let wishlist = JSON.parse(localStorage.getItem('tornado_wishlist') || '[]');

  function updateWishlistBadge() {
    document.querySelectorAll('[data-wishlist-count]').forEach(el => {
      el.textContent = wishlist.length;
    });
  }

  updateWishlistBadge();

  document.querySelectorAll('[data-wishlist-add]').forEach(btn => {
    const pid = btn.dataset.wishlistAdd;
    if (wishlist.includes(pid)) {
      btn.classList.add('active');
    }

    btn.addEventListener('click', (e) => {
      e.preventDefault();
      if (wishlist.includes(pid)) {
        wishlist = wishlist.filter(id => id !== pid);
        btn.classList.remove('active');
      } else {
        wishlist.push(pid);
        btn.classList.add('active');
      }
      localStorage.setItem('tornado_wishlist', JSON.stringify(wishlist));
      updateWishlistBadge();
    });
  });
});

  /* ------------------------------------------------------------------------
     PHASE 4: FILTER DRAWER & PREDICTIVE SEARCH LOGIC
     ------------------------------------------------------------------------ */
  const filterDrawerBtn = document.querySelector('[data-filter-drawer-toggle]');
  const filterDrawer = document.querySelector('[data-filter-drawer]');
  const filterOverlay = document.querySelector('[data-filter-overlay]');
  const filterClose = document.querySelector('[data-filter-drawer-close]');

  function openFilterDrawer() {
    if (filterDrawer && filterOverlay) {
      filterDrawer.classList.add('active');
      filterOverlay.classList.add('active');
      document.body.style.overflow = 'hidden';
    }
  }

  function closeFilterDrawer() {
    if (filterDrawer && filterOverlay) {
      filterDrawer.classList.remove('active');
      filterOverlay.classList.remove('active');
      document.body.style.overflow = '';
    }
  }

  if (filterDrawerBtn) filterDrawerBtn.addEventListener('click', openFilterDrawer);
  if (filterClose) filterClose.addEventListener('click', closeFilterDrawer);
  if (filterOverlay) filterOverlay.addEventListener('click', closeFilterDrawer);

  // Predictive Search API Handler
  const predInput = document.querySelector('[data-predictive-search-input]');
  const predResults = document.querySelector('[data-predictive-search-results]');

  if (predInput && predResults) {
    let debounceTimer;
    predInput.addEventListener('input', function() {
      clearTimeout(debounceTimer);
      const query = this.value.trim();

      if (query.length < 2) {
        predResults.innerHTML = '<p class="text-secondary text-sm">Saisissez un mot-clé pour commencer la recherche...</p>';
        return;
      }

      debounceTimer = setTimeout(async () => {
        try {
          const response = await fetch(`/search/suggest.json?q=${encodeURIComponent(query)}&resources[type]=product&resources[limit]=4`);
          if (response.ok) {
            const data = await response.json();
            const products = data.resources.results.products || [];
            
            if (products.length > 0) {
              let html = '<div class="predictive-results-list">';
              products.forEach(p => {
                html += `
                  <a href="${p.url}" class="predictive-item">
                    <img src="${p.image}" width="50" height="65" alt="${p.title}">
                    <div>
                      <div class="font-bold text-sm text-white">${p.title}</div>
                      <div class="text-gold-gradient text-xs font-bold">${p.price} €</div>
                    </div>
                  </a>
                `;
              });
              html += '</div>';
              predResults.innerHTML = html;
            } else {
              predResults.innerHTML = `<p class="text-secondary text-sm">Aucun résultat trouvé pour "${query}".</p>`;
            }
          }
        } catch (e) {
          console.error('Predictive Search Error:', e);
        }
      }, 250);
    });
  }
